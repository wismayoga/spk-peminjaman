<?php

namespace App\Http\Controllers;

use App\Models\Alternatif;
use App\Models\JenisVariabel;
use App\Models\Penilaian;
use App\Models\Variabel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class penilaianController extends Controller
{
    public function index()
    {
        $alternatifs = DB::table('alternatifs')
            ->leftJoin('penilaians as tabel_penilaian', 'tabel_penilaian.id_alternatif', '=', 'alternatifs.id')
            ->select('alternatifs.*', 'tabel_penilaian.updated_at as tanggal')
            ->simplePaginate(10);
        $penilaians = Penilaian::all();
        $variabels = Variabel::all();
        $jenisJaminan = JenisVariabel::where('id_variabel', '=', 4)->get();

        //render view with posts
        return view('dashboard.penilaian', [
            'alternatifs' => $alternatifs,
            'penilaians' => $penilaians,
            'variabels' => $variabels,
            'jenisJaminan' => $jenisJaminan,
        ]);
    }

    public function cari(Request $request)
    {
        $cari = $request->cari;

        $alternatifs = DB::table('alternatifs')
            ->where('alternatifs.nama', 'like', "%" . $cari . "%")
            ->leftJoin('penilaians as tabel_penilaian', 'tabel_penilaian.id_alternatif', '=', 'alternatifs.id')
            ->select('alternatifs.*', 'tabel_penilaian.updated_at as tanggal')
            ->get();
        $penilaians = Penilaian::all();
        $variabels = Variabel::all();
        $jenisJaminan = JenisVariabel::where('id_variabel', '=', 4)->get();

        //render view with posts
        return view('dashboard.penilaian', [
            'alternatifs' => $alternatifs,
            'penilaians' => $penilaians,
            'variabels' => $variabels,
            'jenisJaminan' => $jenisJaminan,
        ]);
    }

    public function store(Request $request)
    {
        //validate form
        // $this->validate($request, [
        //     'nama'   => 'required|min:5'
        // ]);

        Penilaian::create([
            'id_alternatif'     => $request->id_alternatif,
            'id_jenisVariabel'     => $request->jenis,
            'rk'     => $request->rk,
            'penghasilan'     => $request->penghasilan,
            'tanggungan'     => $request->tanggungan,
            'jaminan'     => $request->jaminan,
        ]);

        return redirect()->route('penilaian.index')->with('success', 'Penilaian berhasil ditambah.');
    }

    public function update(Request $request, Penilaian $penilaian)
    {
        // $this->validate($request, [
        //     'nama'   => 'required|min:5'
        // ]);

        $penilaian->update([
            'id_alternatif'     => $request->id_alternatif,
            'id_jenisVariabel'     => $request->jenis,
            'rk'     => $request->rk,
            'penghasilan'     => $request->penghasilan,
            'tanggungan'     => $request->tanggungan,
            'jaminan'     => $request->jaminan,
        ]);

        return redirect()->route('penilaian.index')->with(['success' => 'Penilaian berhasil diubah.']);
    }
}
